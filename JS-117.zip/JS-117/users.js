const user = `{
    "salutation": "Miss.",
    "firstName": "Geneva",
    "middleName": "Beth",
    "lastName": "Collins",
    "office": "High School",
    "roomNumber": 488,
    "phoneExt": 392,
    "emailPersonal": "geneva.collins@personal.net",
    "status": true
  }`